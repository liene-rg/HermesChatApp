﻿namespace HermesChatTeamB_v3.Models
{
    public enum ChatType
    {
        Room,
        Private
    }
}
