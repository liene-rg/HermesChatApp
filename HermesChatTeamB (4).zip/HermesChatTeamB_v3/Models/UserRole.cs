﻿namespace HermesChatTeamB_v3.Models
{
    public enum UserRole
    {
        Admin, // someone who has created the room, can delete the room
        Member,
        Guest
    }
}
