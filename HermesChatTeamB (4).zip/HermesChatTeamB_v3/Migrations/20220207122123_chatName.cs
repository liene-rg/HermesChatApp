﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HermesChatTeamB_v3.Migrations
{
    public partial class chatName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
